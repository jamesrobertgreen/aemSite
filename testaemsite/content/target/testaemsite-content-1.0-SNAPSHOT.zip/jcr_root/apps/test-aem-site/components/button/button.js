"use strict";
use(function() {
    return {
        text: ''
    }
});